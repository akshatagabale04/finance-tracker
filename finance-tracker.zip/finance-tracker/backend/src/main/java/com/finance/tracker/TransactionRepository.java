package com.finance.tracker;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDate;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    // Projections: each native query below returns rows shaped like one of these
    interface CategoryTotal { String getCategory(); Long getTotal(); Double getPct(); }
    interface BudgetUsage   { String getCategory(); Long getBudget(); Long getSpent(); }
    interface MonthTrend    { String getMonth(); Long getIncome(); Long getExpense(); }

    /** Filter by month range, and optionally by type and category. */
    @Query(value = """
            SELECT * FROM transactions
            WHERE txn_date >= :fromDate AND txn_date < :toDate
              AND (CAST(:type AS text) IS NULL OR type = CAST(:type AS text))
              AND (CAST(:category AS text) IS NULL OR category = CAST(:category AS text))
            ORDER BY txn_date DESC, id DESC
            """, nativeQuery = true)
    List<Transaction> filter(@Param("fromDate") LocalDate fromDate, @Param("toDate") LocalDate toDate,
                             @Param("type") String type, @Param("category") String category);

    /** Monthly category breakdown. SUM(SUM()) OVER () is a window function giving the grand total for % share. */
    @Query(value = """
            SELECT category AS category,
                   CAST(SUM(amount_paise) AS BIGINT) AS total,
                   CAST(ROUND(100.0 * SUM(amount_paise) / SUM(SUM(amount_paise)) OVER (), 1) AS DOUBLE PRECISION) AS pct
            FROM transactions
            WHERE type = 'EXPENSE' AND txn_date >= :fromDate AND txn_date < :toDate
            GROUP BY category
            ORDER BY total DESC
            """, nativeQuery = true)
    List<CategoryTotal> categoryBreakdown(@Param("fromDate") LocalDate fromDate, @Param("toDate") LocalDate toDate);

    /** Budget vs actual: LEFT JOIN keeps categories that have a budget but no spending yet. */
    @Query(value = """
            SELECT b.category AS category,
                   b.monthly_limit_paise AS budget,
                   CAST(COALESCE(SUM(t.amount_paise), 0) AS BIGINT) AS spent
            FROM budgets b
            LEFT JOIN transactions t
                   ON t.category = b.category AND t.type = 'EXPENSE'
                  AND t.txn_date >= :fromDate AND t.txn_date < :toDate
            GROUP BY b.category, b.monthly_limit_paise
            ORDER BY b.category
            """, nativeQuery = true)
    List<BudgetUsage> budgetVsActual(@Param("fromDate") LocalDate fromDate, @Param("toDate") LocalDate toDate);

    /** Income vs expense per month using conditional aggregation (FILTER). */
    @Query(value = """
            SELECT to_char(date_trunc('month', txn_date), 'YYYY-MM') AS month,
                   CAST(COALESCE(SUM(amount_paise) FILTER (WHERE type = 'INCOME'), 0) AS BIGINT) AS income,
                   CAST(COALESCE(SUM(amount_paise) FILTER (WHERE type = 'EXPENSE'), 0) AS BIGINT) AS expense
            FROM transactions
            WHERE txn_date >= :fromDate AND txn_date < :toDate
            GROUP BY 1
            ORDER BY 1
            """, nativeQuery = true)
    List<MonthTrend> monthlyTrend(@Param("fromDate") LocalDate fromDate, @Param("toDate") LocalDate toDate);
}
