package com.finance.tracker;

import jakarta.validation.Valid;
import org.springframework.data.domain.Sort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/budgets")
public class BudgetController {
    private final BudgetRepository repo;

    public BudgetController(BudgetRepository repo) { this.repo = repo; }

    @GetMapping
    public List<Budget> list() { return repo.findAll(Sort.by("category")); }

    /** Create or update the monthly limit for a category. */
    @PutMapping
    public Budget upsert(@Valid @RequestBody Budget b) {
        b.id = null;
        Budget target = repo.findByCategory(b.category).orElse(b);
        target.monthlyLimitPaise = b.monthlyLimitPaise;
        return repo.save(target);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        repo.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
