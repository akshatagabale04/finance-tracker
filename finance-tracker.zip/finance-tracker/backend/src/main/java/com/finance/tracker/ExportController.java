package com.finance.tracker;

import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Phrase;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;

@RestController
@RequestMapping("/api/export")
public class ExportController {
    private final TransactionRepository repo;

    public ExportController(TransactionRepository repo) { this.repo = repo; }

    private List<Transaction> rows(String month) {
        return repo.filter(Months.start(month), Months.end(month), null, null);
    }

    @GetMapping("/csv")
    public ResponseEntity<byte[]> csv(@RequestParam String month) {
        StringBuilder sb = new StringBuilder("Date,Type,Category,Description,Amount (INR)\n");
        for (Transaction t : rows(month)) {
            sb.append(t.txnDate).append(',').append(t.type).append(',').append(cell(t.category)).append(',')
              .append(cell(t.description)).append(',').append(rupees(t.amountPaise)).append('\n');
        }
        return file(sb.toString().getBytes(StandardCharsets.UTF_8), "text/csv", "statement-" + month + ".csv");
    }

    @GetMapping("/pdf")
    public ResponseEntity<byte[]> pdf(@RequestParam String month) throws DocumentException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        Document doc = new Document(PageSize.A4);
        PdfWriter.getInstance(doc, out);
        doc.open();
        doc.add(new Paragraph("Statement for " + month, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16)));

        PdfPTable table = new PdfPTable(new float[]{2, 2, 2, 4, 2});
        table.setWidthPercentage(100);
        table.setSpacingBefore(12);
        for (String h : List.of("Date", "Type", "Category", "Description", "Amount (Rs.)")) {
            table.addCell(new PdfPCell(new Phrase(h, FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10))));
        }
        long income = 0, expense = 0;
        for (Transaction t : rows(month)) {
            table.addCell(t.txnDate.toString());
            table.addCell(t.type);
            table.addCell(t.category);
            table.addCell(t.description == null ? "" : t.description);
            table.addCell(rupees(t.amountPaise));
            if ("INCOME".equals(t.type)) income += t.amountPaise; else expense += t.amountPaise;
        }
        doc.add(table);
        doc.add(new Paragraph(String.format(Locale.ROOT, "%nIncome: Rs. %s   Expenses: Rs. %s   Net: Rs. %s",
                rupees(income), rupees(expense), rupees(income - expense)),
                FontFactory.getFont(FontFactory.HELVETICA_BOLD, 11)));
        doc.close();
        return file(out.toByteArray(), "application/pdf", "statement-" + month + ".pdf");
    }

    private static String rupees(long paise) { return String.format(Locale.ROOT, "%.2f", paise / 100.0); }

    /** Quote a CSV cell; neutralise leading = + - @ so Excel does not run it as a formula. */
    private static String cell(String s) {
        if (s == null || s.isEmpty()) return "";
        if ("=+-@".indexOf(s.charAt(0)) >= 0) s = "'" + s;
        return "\"" + s.replace("\"", "\"\"") + "\"";
    }

    private static ResponseEntity<byte[]> file(byte[] body, String type, String name) {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + name + "\"")
                .contentType(MediaType.parseMediaType(type))
                .body(body);
    }
}
