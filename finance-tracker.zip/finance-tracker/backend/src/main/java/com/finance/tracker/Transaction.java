package com.finance.tracker;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name = "transactions")
public class Transaction {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @Pattern(regexp = "INCOME|EXPENSE")
    public String type;
    @NotBlank @Size(max = 50)
    public String category;
    @Positive
    public long amountPaise;          // money is stored as integer paise, never floats
    @Size(max = 255)
    public String description;
    @NotNull
    public LocalDate txnDate;
}
