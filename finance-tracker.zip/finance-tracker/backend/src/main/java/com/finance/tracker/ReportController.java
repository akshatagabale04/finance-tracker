package com.finance.tracker;

import org.springframework.web.bind.annotation.*;
import java.time.YearMonth;
import java.util.List;

@RestController
@RequestMapping("/api/reports")
public class ReportController {
    record Slice(String category, long total, double pct) {}
    record Usage(String category, long budget, long spent) {}
    record Trend(String month, long income, long expense) {}

    private final TransactionRepository repo;

    public ReportController(TransactionRepository repo) { this.repo = repo; }

    @GetMapping("/category-breakdown")
    public List<Slice> categoryBreakdown(@RequestParam String month) {
        return repo.categoryBreakdown(Months.start(month), Months.end(month)).stream()
                .map(r -> new Slice(r.getCategory(), r.getTotal(), r.getPct())).toList();
    }

    @GetMapping("/budget-vs-actual")
    public List<Usage> budgetVsActual(@RequestParam String month) {
        return repo.budgetVsActual(Months.start(month), Months.end(month)).stream()
                .map(r -> new Usage(r.getCategory(), r.getBudget(), r.getSpent())).toList();
    }

    @GetMapping("/monthly-trend")
    public List<Trend> monthlyTrend(@RequestParam String month, @RequestParam(defaultValue = "6") int months) {
        int n = Math.max(1, Math.min(months, 24));
        YearMonth last = Months.parse(month);
        return repo.monthlyTrend(last.minusMonths(n - 1L).atDay(1), last.plusMonths(1).atDay(1)).stream()
                .map(r -> new Trend(r.getMonth(), r.getIncome(), r.getExpense())).toList();
    }
}
