package com.finance.tracker;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "budgets")
public class Budget {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @NotBlank @Size(max = 50)
    public String category;
    @Positive
    public long monthlyLimitPaise;
}
