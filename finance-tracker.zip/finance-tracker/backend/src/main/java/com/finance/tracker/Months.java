package com.finance.tracker;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeParseException;

/** Turns a "YYYY-MM" string into a half-open date range [start, end). */
final class Months {
    private Months() {}

    static YearMonth parse(String month) {
        try {
            return YearMonth.parse(month);
        } catch (DateTimeParseException e) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "month must look like 2026-11");
        }
    }
    static LocalDate start(String month) { return parse(month).atDay(1); }
    static LocalDate end(String month)   { return parse(month).plusMonths(1).atDay(1); }
}
