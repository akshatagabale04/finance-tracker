CREATE TABLE transactions (
    id           BIGSERIAL PRIMARY KEY,
    type         VARCHAR(10)  NOT NULL CHECK (type IN ('INCOME', 'EXPENSE')),
    category     VARCHAR(50)  NOT NULL,
    amount_paise BIGINT       NOT NULL CHECK (amount_paise > 0),
    description  VARCHAR(255),
    txn_date     DATE         NOT NULL
);
CREATE INDEX idx_txn_date ON transactions (txn_date);
CREATE INDEX idx_txn_category ON transactions (category);

-- One row per category: a limit that applies to every month (recurring monthly budget)
CREATE TABLE budgets (
    id                  BIGSERIAL PRIMARY KEY,
    category            VARCHAR(50) NOT NULL UNIQUE,
    monthly_limit_paise BIGINT      NOT NULL CHECK (monthly_limit_paise > 0)
);
