-- Demo data for the last 6 months. Delete this file to start with an empty database.
INSERT INTO budgets (category, monthly_limit_paise) VALUES
  ('Food', 1000000), ('Transport', 400000), ('Shopping', 800000), ('Bills', 1500000), ('Entertainment', 300000);

INSERT INTO transactions (type, category, amount_paise, description, txn_date)
SELECT 'INCOME', 'Salary', 8500000, 'Monthly salary',
       (date_trunc('month', CURRENT_DATE) - make_interval(months => m) + interval '1 day')::date
FROM generate_series(0, 5) AS m;

INSERT INTO transactions (type, category, amount_paise, description, txn_date)
SELECT 'EXPENSE', c.category, c.amt + (m * 7919 % 50000), c.descr,
       (date_trunc('month', CURRENT_DATE) - make_interval(months => m) + c.day * interval '1 day')::date
FROM generate_series(0, 5) AS m,
     (VALUES ('Food', 650000, 'Groceries and dining', 4),
             ('Transport', 250000, 'Fuel and cabs', 9),
             ('Shopping', 500000, 'Online shopping', 14),
             ('Bills', 1200000, 'Rent share and utilities', 2),
             ('Entertainment', 180000, 'Movies and subscriptions', 19)) AS c(category, amt, descr, day);
