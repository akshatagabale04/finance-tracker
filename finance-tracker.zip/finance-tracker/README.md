# Ledgerly: Personal Finance & Expense Tracker

React + Spring Boot + PostgreSQL, built on the same pattern as the e-commerce reference
(React -> Spring Boot REST -> PostgreSQL, Flyway migrations, multi-stage Docker, GitHub Actions, Kubernetes).

## Run everything (Docker)
    docker compose up --build
    open http://localhost:3000        # UI (nginx proxies /api to the backend)
    # API: http://localhost:8080/api/...

## Run for development
    docker compose up postgres-db -d
    cd backend && mvn spring-boot:run          # :8080, Flyway creates tables + demo data
    cd frontend && npm install && npm run dev  # :3000, /api proxied to :8080

## REST API (all money in integer paise)
| Method | Endpoint | Purpose |
|---|---|---|
| GET/POST | /api/transactions?month=2026-11&type=&category= | list (filtered) / add |
| PUT/DELETE | /api/transactions/{id} | edit / delete |
| GET/PUT | /api/budgets | list / set a recurring monthly limit |
| GET | /api/reports/category-breakdown?month= | SQL: GROUP BY + window-function % share |
| GET | /api/reports/budget-vs-actual?month= | SQL: LEFT JOIN budgets to spending |
| GET | /api/reports/monthly-trend?month=&months=6 | SQL: conditional aggregation (FILTER) |
| GET | /api/export/csv?month= , /api/export/pdf?month= | statement download |

The three report queries live in `TransactionRepository.java` as native PostgreSQL.
Demo data comes from `V2__demo_data.sql`; delete that file for an empty start.
