import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { inr } from './api';

const COLORS = ['#14213d', '#1b998b', '#f4a259', '#d1495b', '#7b6d8d', '#5c8001', '#3a86c8', '#8d99ae'];
const money = (v) => inr(v);
const axisK = (v) => '₹' + Math.round(v / 100000) + 'k';
const Empty = () => <p className="empty">Nothing here yet. Add a transaction or set a budget.</p>;

export function CategoryPie({ data }) {
  if (!data.length) return <Empty />;
  return (
    <ResponsiveContainer width="100%" height={280}>
      <PieChart>
        <Pie data={data} dataKey="total" nameKey="category" innerRadius={62} outerRadius={104} paddingAngle={2}>
          {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
        </Pie>
        <Tooltip formatter={money} />
        <Legend />
      </PieChart>
    </ResponsiveContainer>
  );
}

export function TrendBar({ data }) {
  if (!data.length) return <Empty />;
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="month" />
        <YAxis tickFormatter={axisK} width={56} />
        <Tooltip formatter={money} />
        <Legend />
        <Bar dataKey="income" name="Income" fill="#1b998b" radius={[3, 3, 0, 0]} />
        <Bar dataKey="expense" name="Expenses" fill="#d1495b" radius={[3, 3, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}

export function BudgetBar({ data }) {
  if (!data.length) return <Empty />;
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={data}>
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="category" />
        <YAxis tickFormatter={axisK} width={56} />
        <Tooltip formatter={money} />
        <Legend />
        <Bar dataKey="budget" name="Budget" fill="#b8c4d6" radius={[3, 3, 0, 0]} />
        <Bar dataKey="spent" name="Spent" fill="#14213d" radius={[3, 3, 0, 0]} />
      </BarChart>
    </ResponsiveContainer>
  );
}
