import { useCallback, useEffect, useState } from 'react';
import { api, inr } from './api';
import { CategoryPie, TrendBar, BudgetBar } from './Charts';
import './App.css';

const CATEGORIES = ['Food', 'Transport', 'Shopping', 'Bills', 'Entertainment', 'Health', 'Salary', 'Other'];
const today = () => new Date().toLocaleDateString('en-CA'); // local YYYY-MM-DD
const blank = () => ({ type: 'EXPENSE', category: 'Food', amount: '', description: '', txnDate: today() });

export default function App() {
  const [month, setMonth] = useState(today().slice(0, 7));
  const [filter, setFilter] = useState({ type: '', category: '' });
  const [txns, setTxns] = useState([]);
  const [slices, setSlices] = useState([]);
  const [usage, setUsage] = useState([]);
  const [trend, setTrend] = useState([]);
  const [form, setForm] = useState(null);
  const [budget, setBudget] = useState({ category: 'Food', limit: '' });
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    try {
      const [t, s, u, tr] = await Promise.all([
        api.transactions(month, filter.type, filter.category),
        api.breakdown(month), api.budgetVsActual(month), api.trend(month),
      ]);
      setTxns(t); setSlices(s); setUsage(u); setTrend(tr); setError('');
    } catch {
      setError('Cannot reach the server. Start the backend and refresh.');
    }
  }, [month, filter]);

  useEffect(() => { load(); }, [load]);

  const cur = trend.find((x) => x.month === month) || { income: 0, expense: 0 };
  const net = cur.income - cur.expense;

  async function saveTxn(e) {
    e.preventDefault();
    try {
      await api.saveTxn({
        id: form.id, type: form.type, category: form.category, description: form.description,
        txnDate: form.txnDate, amountPaise: Math.round(parseFloat(form.amount) * 100),
      });
      setForm(null); load();
    } catch { setError('Could not save. Check that the amount is above zero and the date is set.'); }
  }

  async function saveBudget(e) {
    e.preventDefault();
    try {
      await api.saveBudget({ category: budget.category, monthlyLimitPaise: Math.round(parseFloat(budget.limit) * 100) });
      setBudget({ ...budget, limit: '' }); load();
    } catch { setError('Could not save the budget. Enter a limit above zero.'); }
  }

  async function remove(t) {
    if (!window.confirm(`Delete "${t.description || t.category}"?`)) return;
    await api.deleteTxn(t.id); load();
  }

  return (
    <div className="layout">
      <aside className="side">
        <h1>Ledgerly</h1>
        <label className="month">Month
          <input type="month" value={month} onChange={(e) => e.target.value && setMonth(e.target.value)} />
        </label>
        <p className="net-label">Net this month</p>
        <p className={'net ' + (net < 0 ? 'neg' : '')}>{inr(net)}</p>
        <dl className="sums">
          <div><dt>Income</dt><dd>{inr(cur.income)}</dd></div>
          <div><dt>Expenses</dt><dd>{inr(cur.expense)}</dd></div>
        </dl>
        <div className="exports">
          <a href={api.exportUrl('csv', month)}>Download CSV</a>
          <a href={api.exportUrl('pdf', month)}>Download PDF</a>
        </div>
      </aside>

      <main>
        {error && <p className="error" role="alert">{error}</p>}

        <section className="charts">
          <div><h2>Spending by category</h2><CategoryPie data={slices} /></div>
          <div><h2>Income and expenses, last 6 months</h2><TrendBar data={trend} /></div>
        </section>

        <section>
          <h2>Budget vs actual</h2>
          <BudgetBar data={usage} />
          <ul className="meters">
            {usage.map((u) => {
              const pct = Math.min(100, (u.spent / u.budget) * 100);
              return (
                <li key={u.category}>
                  <span>{u.category}</span>
                  <div className="track"><div className={'fill ' + (u.spent > u.budget ? 'over' : '')} style={{ width: pct + '%' }} /></div>
                  <span className={u.spent > u.budget ? 'over-text' : ''}>{inr(u.spent)} of {inr(u.budget)}</span>
                </li>
              );
            })}
          </ul>
          <form className="inline" onSubmit={saveBudget}>
            <select value={budget.category} onChange={(e) => setBudget({ ...budget, category: e.target.value })}>
              {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
            </select>
            <input type="number" min="1" step="any" placeholder="Monthly limit (₹)" required value={budget.limit}
                   onChange={(e) => setBudget({ ...budget, limit: e.target.value })} />
            <button>Save budget</button>
          </form>
        </section>

        <section>
          <div className="row">
            <h2>Transactions</h2>
            <button onClick={() => setForm(blank())}>Add transaction</button>
          </div>

          {form && (
            <form className="inline form" onSubmit={saveTxn}>
              <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                <option value="EXPENSE">Expense</option><option value="INCOME">Income</option>
              </select>
              <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
                {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
              </select>
              <input type="number" min="0.01" step="0.01" placeholder="Amount (₹)" required value={form.amount}
                     onChange={(e) => setForm({ ...form, amount: e.target.value })} />
              <input type="date" required value={form.txnDate} onChange={(e) => setForm({ ...form, txnDate: e.target.value })} />
              <input placeholder="Description" value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} />
              <button>{form.id ? 'Save changes' : 'Add transaction'}</button>
              <button type="button" className="ghost" onClick={() => setForm(null)}>Cancel</button>
            </form>
          )}

          <div className="inline filters">
            <select value={filter.type} onChange={(e) => setFilter({ ...filter, type: e.target.value })}>
              <option value="">All types</option><option value="EXPENSE">Expenses</option><option value="INCOME">Income</option>
            </select>
            <select value={filter.category} onChange={(e) => setFilter({ ...filter, category: e.target.value })}>
              <option value="">All categories</option>
              {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
            </select>
          </div>

          <div className="scroll">
            <table>
              <thead><tr><th>Date</th><th>Category</th><th>Description</th><th className="num">Amount</th><th /></tr></thead>
              <tbody>
                {txns.map((t) => (
                  <tr key={t.id}>
                    <td>{t.txnDate}</td><td>{t.category}</td><td>{t.description}</td>
                    <td className={'num ' + (t.type === 'INCOME' ? 'in' : 'out')}>{t.type === 'INCOME' ? '+' : '-'}{inr(t.amountPaise)}</td>
                    <td className="acts">
                      <button className="ghost" onClick={() => setForm({ ...t, amount: t.amountPaise / 100 })}>Edit</button>
                      <button className="ghost" onClick={() => remove(t)}>Delete</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!txns.length && <p className="empty">No transactions match. Change the filters or add one.</p>}
          </div>
        </section>
      </main>
    </div>
  );
}
