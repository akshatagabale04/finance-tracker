// All calls go to /api/* (Vite proxy in dev, nginx proxy in Docker/Kubernetes).
async function call(url, method = 'GET', body) {
  const res = await fetch(url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : undefined,
    body: body ? JSON.stringify(body) : undefined,
  });
  if (!res.ok) throw new Error(`${method} ${url} failed with ${res.status}`);
  return res.status === 204 ? null : res.json();
}

export const inr = (paise) =>
  (paise / 100).toLocaleString('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 });

export const api = {
  transactions: (month, type, category) => {
    const q = new URLSearchParams({ month });
    if (type) q.set('type', type);
    if (category) q.set('category', category);
    return call(`/api/transactions?${q}`);
  },
  saveTxn: (t) => (t.id ? call(`/api/transactions/${t.id}`, 'PUT', t) : call('/api/transactions', 'POST', t)),
  deleteTxn: (id) => call(`/api/transactions/${id}`, 'DELETE'),
  saveBudget: (b) => call('/api/budgets', 'PUT', b),
  breakdown: (month) => call(`/api/reports/category-breakdown?month=${month}`),
  budgetVsActual: (month) => call(`/api/reports/budget-vs-actual?month=${month}`),
  trend: (month) => call(`/api/reports/monthly-trend?month=${month}&months=6`),
  exportUrl: (format, month) => `/api/export/${format}?month=${month}`,
};
